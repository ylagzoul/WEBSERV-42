#!/usr/bin/env bash
# =============================================================================
#  webserv — ADVANCED / adversarial test suite
#  Deep edge cases an evaluator (or attacker) will throw at the server:
#  request-line & header malformations, body/Content-Length limits, chunked
#  request bodies, advanced path traversal, CGI pipe deadlocks & failures,
#  multipart corner cases, and connection/DoS behaviour (slowloris, keep-alive
#  reuse, idle floods, pipelining).
#
#  Hang-prone CGI tests run on a sacrificial instance (port 8083) so a deadlock
#  cannot stall the rest of the run. Every probe is timeout-bounded.
#
#  Usage: bash tests/advanced.sh
# =============================================================================
source "$(dirname "$0")/lib.sh"

# raw-request helpers: pipe literal bytes, parse the response
rawst(){ printf '%b' "$2" | python3 "$PY" "$H" "$1" --raw --show status     --timeout 6; }
rawsl(){ printf '%b' "$2" | python3 "$PY" "$H" "$1" --raw --show statusline  --timeout 6; }
rawbd(){ printf '%b' "$2" | python3 "$PY" "$H" "$1" --raw --show body        --timeout 6; }

build_server
setup_sandbox
valgrind_leak_check   # run first, in a fresh environment (most reliable for valgrind)
ensure_clean

sec "LAUNCH SERVERS"
"$BIN" "$MAIN"  > "$SB/srvA.log" 2>&1 & SRVA=$!
"$BIN" "$SMALL" > "$SB/srvB.log" 2>&1 & SRVB=$!
SRVC=""; SRVD=""
cleanup(){ kill -9 $SRVA $SRVB $SRVC $SRVD 2>/dev/null; pkill -9 -x webserv 2>/dev/null; pkill -9 -f "$SB/www/cgi-bin" 2>/dev/null; wait 2>/dev/null; }
trap cleanup EXIT
wait_port $P1 && ok "server up on $P1" || { no "server failed"; cat "$SB/srvA.log"; exit 1; }
wait_port $P2 && ok "small server up on $P2" || no "small server failed"

# =============================================================================
sec "A. REQUEST-LINE EDGE CASES"
inset_w "multiple spaces in request line"  "$(rawst $P1 'GET  /hello.txt  HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')" "200 400"
inset_w "tab-separated request line"       "$(rawst $P1 'GET\t/hello.txt\tHTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')" "200 400"
eq    "absolute-form URI -> 400"           400 "$(rawst $P1 'GET http://localhost/hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')"
eq    "asterisk-form OPTIONS * -> 400"     400 "$(rawst $P1 'OPTIONS * HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')"
eq    "lowercase method 'get' -> 400"      400 "$(rawst $P1 'get /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')"
eq    "HEAD method -> 400 (unsupported)"   400 "$(rawst $P1 'HEAD /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')"
eq    "PUT method -> 400"                   400 "$(rawst $P1 'PUT /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n')"
eq    "missing HTTP version -> 400"        400 "$(rawst $P1 'GET /hello.txt\r\nHost: x\r\nConnection: close\r\n\r\n')"
inset_w "trailing garbage after version"   "$(rawst $P1 'GET /hello.txt HTTP/1.1 EXTRA\r\nHost: x\r\nConnection: close\r\n\r\n')" "200 400"
inset_w "bogus version HTTP/9.9 -> 400/505" "$(rawst $P1 'GET /hello.txt HTTP/9.9\r\nHost: x\r\nConnection: close\r\n\r\n')" "400 505"

# =============================================================================
sec "B. HEADER EDGE CASES"
eq    "duplicate Host -> 400"              400 "$(rawst $P1 'GET / HTTP/1.1\r\nHost: a\r\nHost: b\r\nConnection: close\r\n\r\n')"
eq    "duplicate Content-Length -> 400"    400 "$(rawst $P1 'POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 1\r\nContent-Length: 2\r\nConnection: close\r\n\r\nx')"
eq    "space before colon 'Host :' -> 400" 400 "$(rawst $P1 'GET / HTTP/1.1\r\nHost : x\r\nConnection: close\r\n\r\n')"
eq    "uppercase header name HOST -> 200"  200 "$(rawst $P1 'GET /hello.txt HTTP/1.1\r\nHOST: x\r\nConnection: close\r\n\r\n')"
eq    "obsolete line folding -> 400"       400 "$(rawst $P1 'GET / HTTP/1.1\r\nHost: x\r\nX-Fold: a\r\n b\r\nConnection: close\r\n\r\n')"
# header bomb: 2000 headers (write to file so the \r\n\r\n terminator survives)
python3 -c "open('$SB/hb.req','wb').write(b'GET /hello.txt HTTP/1.1\r\nHost: x\r\n'+b''.join(b'H%d: v\r\n'%i for i in range(2000))+b'Connection: close\r\n\r\n')"
inset_w "2000-header bomb (no crash)"      "$(python3 "$PY" "$H" "$P1" --raw --show status --timeout 8 < "$SB/hb.req")" "200 400 431"
# 64KB single header value
python3 -c "open('$SB/lv.req','wb').write(b'GET /hello.txt HTTP/1.1\r\nHost: x\r\nX-Big: '+b'A'*65536+b'\r\nConnection: close\r\n\r\n')"
inset_w "64KB single header value (no crash)" "$(python3 "$PY" "$H" "$P1" --raw --show status --timeout 8 < "$SB/lv.req")" "200 400 431"

# =============================================================================
sec "C. BODY / CONTENT-LENGTH"
eq    "Content-Length: 0 GET -> 200"       200 "$(rawst $P1 'GET /hello.txt HTTP/1.1\r\nHost: x\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')"
eq    "GET with body (CL ignored) -> 200"  200 "$(rawst $P1 'GET /hello.txt HTTP/1.1\r\nHost: x\r\nContent-Length: 5\r\nConnection: close\r\n\r\nhello')"
eq    "non-numeric Content-Length -> 400"  400 "$(rawst $P1 'POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: abc\r\nConnection: close\r\n\r\nx')"
inset_w "negative Content-Length -> 400"   "$(rawst $P1 'POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: -1\r\nConnection: close\r\n\r\nx')" "400"
# max_size boundary on small.conf (max 100): 100 ok, 101 rejected
B100=$(python3 -c "print('GET /hello.txt HTTP/1.1\r\nHost: x\r\nContent-Length: 100\r\nConnection: close\r\n\r\n'+'y'*100, end='')")
eq    "CL=100 == max_size accepted -> 200" 200 "$(printf '%s' "$B100" | python3 "$PY" "$H" "$P2" --raw --show status --timeout 6)"
B101=$(python3 -c "print('POST /upload HTTP/1.1\r\nHost: x\r\nContent-Length: 101\r\nConnection: close\r\n\r\n'+'y'*101, end='')")
inset_w "CL=101 > max_size rejected -> 413/400" "$(printf '%s' "$B101" | python3 "$PY" "$H" "$P2" --raw --show status --timeout 6)" "413 400"

# =============================================================================
sec "D. CHUNKED REQUEST BODY"
CHK='POST /cgi-bin/info.py HTTP/1.1\r\nHost: x\r\nContent-Type: text/plain\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n5\r\nhello\r\n0\r\n\r\n'
has   "chunked body decoded (BODY_LEN 5)" "BODY_LEN: 5" "$(rawbd $P1 "$CHK")"
CHX='POST /cgi-bin/info.py HTTP/1.1\r\nHost: x\r\nContent-Type: text/plain\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\nC\r\nhelloworld12\r\n0\r\n\r\n'
has   "uppercase-hex chunk size (BODY_LEN 12)" "BODY_LEN: 12" "$(rawbd $P1 "$CHX")"
CHB='POST /cgi-bin/info.py HTTP/1.1\r\nHost: x\r\nContent-Type: text/plain\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\nZZ\r\nhello\r\n0\r\n\r\n'
inset "malformed chunk size -> 400"        "$(rawst $P1 "$CHB")" "400"
# Content-Length AND Transfer-Encoding both present (request-smuggling vector)
SMG='POST /cgi-bin/info.py HTTP/1.1\r\nHost: x\r\nContent-Type: text/plain\r\nContent-Length: 5\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n5\r\nhello\r\n0\r\n\r\n'
inset_w "CL+TE both present (smuggling) handled" "$(rawst $P1 "$SMG")" "200 400"

# =============================================================================
sec "E. PATH TRAVERSAL (advanced)"
eq    "legit .. inside root /pub/../hello.txt -> 200" 200 "$(st $P1 --path /pub/../hello.txt)"
has   "  serves correct file"              "HELLO_TXT_BODY_OK" "$(bd $P1 --path /pub/../hello.txt)"
eq    "encoded . path /./hello.txt -> 200" 200 "$(st $P1 --path /./hello.txt)"
has   "  encoded /pub/%2e%2e/hello.txt"    "HELLO_TXT_BODY_OK" "$(bd $P1 --path '/pub/%2e%2e/hello.txt')"
inset "encoded-slash %2f traversal blocked" "$(st $P1 --path '/cgi-bin%2f..%2f..%2f..%2f..%2f..%2fetc%2fpasswd')" "403 404"
inset "double-encoded %252e blocked"        "$(st $P1 --path '/%252e%252e%252fetc%252fpasswd')" "403 404"
inset "file with trailing slash /hello.txt/ -> 404/403" "$(st $P1 --path /hello.txt/)" "403 404"

# =============================================================================
sec "F. CGI (deep — input/output pipe handling)"
# small POST body (<1024) works (RAM path)
has   "CGI POST 1023B body (RAM path)"     "BODY_LEN: 1023" "$(bd $P1 --method POST --path /cgi-bin/info.py --header 'Content-Type: text/plain' --body "$(python3 -c 'print("x"*1023,end="")')")"
# >=1024 body goes to temp file -> feedInput temp-file branch
C2K=$(st $P1 --method POST --path /cgi-bin/info.py --header 'Content-Type: text/plain' --body "$(python3 -c 'print("x"*2000,end="")')")
if [ "$C2K" = "200" ]; then ok "CGI POST 2000B body -> 200"
else no "CGI POST >=1024B body -> $C2K (feedInput temp-file branch broken: inverted dup2 / wrong pipe end)"; fi
# CGI that exits non-zero
inset "CGI exit!=0 -> 5xx"                  "$(st $P1 --path /cgi-bin/exitfail.py)" "500 501 502"
# CGI empty body (headers only)
eq    "CGI empty body -> 200"               200 "$(st $P1 --path /cgi-bin/nobody.py)"
# CGI output with no header separator
inset_w "CGI no-header output handled"      "$(st $P1 --path /cgi-bin/nohdr.py)" "200 500 502"
# CGI local redirect via Status:/Location:
inset_w "CGI Status:302 honoured"           "$(st $P1 --path /cgi-bin/loc.py)" "302"
# PATH_INFO style /script.py/extra
inset_w "CGI PATH_INFO /test.py/extra"      "$(st $P1 --path /cgi-bin/test.py/extra)" "200 404"
# big CGI output (>64KB) on a SACRIFICIAL server (may deadlock)
"$BIN" "$ADV" > "$SB/srvC.log" 2>&1 & SRVC=$!; wait_port $P3 && ok "sacrificial server up on $P3" || no "adv server failed"
t0=$(date +%s); BO=$(st $P3 --path /cgi-bin/bigout.py --timeout 8); t1=$(date +%s)
if [ $((t1-t0)) -lt 8 ] && [ "$BO" != "ERR" ] && [ "$BO" != "EMPTY" ]; then ok "CGI 200KB output returned (status $BO)"
else no "CGI output >64KB DEADLOCKS server (waitpid before reading output pipe)"; fi
kill -9 $SRVC 2>/dev/null; SRVC=""
pkill -9 -f "$SB/www/cgi-bin/bigout.py" 2>/dev/null
# CGI child must not inherit/hold the listening socket after the server dies
"$BIN" "$ADV" > "$SB/srvD.log" 2>&1 & SRVD=$!; wait_port $P3 >/dev/null
curl -s --max-time 2 "http://$H:$P3/cgi-bin/hang.py" >/dev/null 2>&1 &
sleep 1; kill -9 $SRVD 2>/dev/null; sleep 0.5
if port_free $P3; then ok "CGI child does not hold listening socket after server killed"
else no "CGI child inherits listening socket (port still bound after server killed; needs FD_CLOEXEC on listen fds)"; fi
pkill -9 -f "$SB/www/cgi-bin/hang.py" 2>/dev/null

# =============================================================================
sec "G. MULTIPART UPLOAD (advanced)"
mk(){ printf '%s' "$1" | sed 's/$/\r/'; }   # LF -> CRLF
# two files in one request
mk '--BB
Content-Disposition: form-data; name="f1"; filename="m1.txt"

ONE
--BB
Content-Disposition: form-data; name="f2"; filename="m2.txt"

TWO
--BB--
' > "$SB/mpx.bin"
st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mpx.bin" >/dev/null; sleep 0.2
{ [ -f "$SB/uploads/m1.txt" ] && [ -f "$SB/uploads/m2.txt" ]; } && ok "two files in one request both written" || no "multi-file upload incomplete"
# boundary-like text inside content must not corrupt the file
mk '--BB
Content-Disposition: form-data; name="f"; filename="tricky.txt"

line--BBnot-a-boundary done
--BB--
' > "$SB/mpt.bin"
st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mpt.bin" >/dev/null; sleep 0.2
case "$(cat "$SB/uploads/tricky.txt" 2>/dev/null)" in
  *"not-a-boundary"*) ok "boundary-like content preserved";;
  *) wn "boundary-like content truncated at bare '--BB' (splitter not CRLF-anchored to \\r\\n--BB; harmless for conformant clients)";;
esac
# filename with spaces
mk '--BB
Content-Disposition: form-data; name="f"; filename="my file.txt"

SPACED
--BB--
' > "$SB/mps.bin"
st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mps.bin" >/dev/null; sleep 0.2
ls "$SB/uploads/" 2>/dev/null | grep -q "file.txt" && ok "filename with spaces handled" || wn "spaced filename not found (check sanitizer)"
# pure form field (no filename) -> no file part
FIELD=$(mk '--BB
Content-Disposition: form-data; name="just"

val
--BB--
')
printf '%s' "$FIELD" > "$SB/mpf.bin"
eq   "form field only (no file) -> 400" 400 "$(st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mpf.bin")"
# large 2MB upload (disk-spill body path) -> intact
{ printf -- '--BB\r\nContent-Disposition: form-data; name="f"; filename="big2.bin"\r\nContent-Type: application/octet-stream\r\n\r\n'; head -c 2097152 /dev/zero | tr '\0' 'Z'; printf -- '\r\n--BB--\r\n'; } > "$SB/mpbig.bin"
st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mpbig.bin" --timeout 15 >/dev/null; sleep 0.3
BSZ=$(wc -c < "$SB/uploads/big2.bin" 2>/dev/null)
eq   "2MB multipart upload intact on disk" 2097152 "$BSZ"

# =============================================================================
sec "H. CONNECTION / KEEP-ALIVE / DoS"
# 100 sequential requests on ONE keep-alive connection
KA100=$(python3 - "$H" "$P1" <<'PY'
import socket,sys
host,port=sys.argv[1],int(sys.argv[2])
def readresp(s):
    buf=b""; s.settimeout(4)
    try:
        while b"\r\n\r\n" not in buf:
            d=s.recv(4096)
            if not d: return 0
            buf+=d
        head,_,rest=buf.partition(b"\r\n\r\n"); cl=0
        for ln in head.split(b"\r\n"):
            if ln.lower().startswith(b"content-length:"): cl=int(ln.split(b":",1)[1])
        while len(rest)<cl:
            d=s.recv(4096)
            if not d: break
            rest+=d
        return int(head.split()[1])
    except: return 0
try:
    s=socket.create_connection((host,port),4); good=0
    for i in range(100):
        last=(i==99); conn=b"close" if last else b"keep-alive"
        s.sendall(b"GET /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: "+conn+b"\r\n\r\n")
        if readresp(s)==200: good+=1
    s.close(); print(good)
except Exception: print("ERR")
PY
)
eq    "100 sequential reqs on 1 keep-alive conn" 100 "$KA100"
# slowloris: a half-sent request must NOT block a normal one
SLOW=$(python3 - "$H" "$P1" <<'PY'
import socket,sys,time
host,port=sys.argv[1],int(sys.argv[2])
slow=socket.create_connection((host,port),4)
slow.sendall(b"GET / HTTP/1.1\r\nHost: x\r\n")   # never finishes headers
time.sleep(0.3)
t0=time.time()
n=socket.create_connection((host,port),4)
n.sendall(b"GET /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
n.settimeout(4); data=b""
try:
    while True:
        d=n.recv(4096)
        if not d: break
        data+=d
except: pass
dt=time.time()-t0
slow.close(); n.close()
print("OK" if (b"HELLO_TXT_BODY_OK" in data and dt<3) else "BLOCKED")
PY
)
eq    "slowloris does NOT block others"     OK "$SLOW"
# 50 idle connections held open, normal request still served
IDLE=$(python3 - "$H" "$P1" <<'PY'
import socket,sys
host,port=sys.argv[1],int(sys.argv[2]); idles=[]
try:
    for _ in range(50):
        idles.append(socket.create_connection((host,port),3))
    n=socket.create_connection((host,port),3)
    n.sendall(b"GET /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
    n.settimeout(4); data=b""
    while True:
        d=n.recv(4096)
        if not d: break
        data+=d
    print("OK" if b"HELLO_TXT_BODY_OK" in data else "FAIL"); n.close()
except Exception: print("ERR")
finally:
    for s in idles: s.close()
PY
)
eq    "serves under 50 idle connections"    OK "$IDLE"
# pipelining: 2 requests in one segment -> how many responses?
PIPE=$(printf 'GET /hello.txt HTTP/1.1\r\nHost: x\r\n\r\nGET /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n' | python3 "$PY" "$H" "$P1" --raw --show raw --timeout 6 | grep -c '^HTTP/1.')
inset_w "pipelined 2 requests -> N responses" "$PIPE" "2 1"

# =============================================================================
summary && exit 0 || exit 1
