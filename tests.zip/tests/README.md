# webserv test suite

Two layers of tests, plus shared infrastructure. Self-contained: each script
builds its own sandbox (`tests/sandbox/`: a www tree + configs), launches the
server, runs every check with a hard per-request timeout, then tears down.
No `sudo`, no `nc` required (`python3` + `curl` only).

## Run

```bash
bash tests/run.sh        # baseline functional + robustness suite
bash tests/advanced.sh   # adversarial / deep edge-case suite
```

Each suite also runs a **valgrind memory/leak check** as its first section (it
launches a fresh server under valgrind on its own port, exercises every handler
path, then terminates it cleanly so valgrind writes a leak report). If
`valgrind` isn't installed the check is skipped with a WARN; everything else
still runs.

Outcomes per check:
- **PASS** — server did the correct thing.
- **FAIL** — a real defect to fix.
- **WARN** — a spec/RFC deviation that is debatable (discuss at defense).

Exit code is non-zero if any FAIL.

## Files

- `lib.sh` — shared infra: colours, counters, assertions, raw-HTTP wrappers,
  sandbox builder, config generator, server launch/teardown, summary.
- `run.sh` — baseline suite (11 sections).
- `advanced.sh` — adversarial suite (8 sections, A–H).
- `http_raw.py` — raw HTTP/1.1 client. Sends literal request bytes (never
  normalises the path), supports missing Host, bad versions, pipelining,
  chunked, `--body-file`, and `--show terminator` to detect malformed responses
  **without hanging**.
- `sandbox/` — generated at runtime (gitignored).

## Coverage

**run.sh** — HTTP compliance · static files · index/autoindex · path traversal
& symlink escape · 414 · redirects · multipart upload (sanitisation, missing
dir, oversize) · DELETE · CGI basics · error pages · multi-port & location
specificity · method enforcement · 100 concurrent · 8 concurrent 5 MB downloads
· slow-client interleave · malformed/disconnect survival · fd-leak · CGI hang.

**advanced.sh** —
- **A. request line:** multiple-space/tab separators, absolute-form,
  `OPTIONS *`, lowercase method, HEAD/PUT, missing version, trailing garbage.
- **B. headers:** duplicate Host / Content-Length, space-before-colon, case
  folding, obsolete line folding, 2000-header bomb, 64 KB header value.
- **C. body / Content-Length:** CL:0, GET-with-body, non-numeric / negative CL,
  `max_size` boundary (100 vs 101).
- **D. chunked request body:** decode, uppercase-hex sizes, malformed size,
  CL+TE smuggling vector.
- **E. traversal (advanced):** legit `..` inside root, `/./`, encoded `%2e%2e`,
  encoded-slash `%2f`, double-encoding `%252e`, trailing slash on a file.
- **F. CGI deep:** POST body RAM vs temp-file path, exit≠0, empty body,
  no-header output, `Status:`/`Location:` redirect, PATH_INFO, **big output**.
- **G. multipart:** multiple files, boundary-in-content, spaced filename,
  field-without-filename, **2 MB upload integrity**.
- **H. connection/DoS:** 100 sequential keep-alive reqs, **slowloris**, 50 idle
  connections, pipelining.

The event loop is **sound under load**: 8×5 MB concurrent downloads arrive
intact, a throttled slow client doesn't block others, slowloris and 50 idle
connections don't starve a normal request, 100 keep-alive requests on one
socket all succeed, 2 MB uploads land intact, header bombs don't crash it.
So the defects below are **specific bugs, not a broken core**.

**Memory (valgrind):** no leaks — `definitely lost: 0`, `indirectly lost: 0`.
~86–160 KB stays "still reachable" (globals/Config, normal for 42). valgrind
does flag **uninitialised-value reads in `HttpResponse::buildNormalBody`**
(`readedLength` isn't initialised in the constructor) — UB, low impact, worth a
one-line fix.

---

## Findings

### FAIL — real defects

| # | Area | Defect | Root cause |
|---|------|--------|-----------|
| 1 | Redirect | 301/empty-body responses have **no header terminator** → clients hang | `HttpResponse::buildHeaders()` only appends the final `\r\n` inside the `fileFd!=-1` and `body>0` branches |
| 2 | Connections | **fd leak**: every keep-alive connection ends in CLOSE_WAIT (`Connection: close` is fine) | `Client::readRequest()` returns on `recv()==0` without setting `Closing`; poll loop never `close()`s it |
| 3 | CGI | **no timeout** → `hang.py` (30 s) freezes the whole server | `CgiHandler::ExecCgi()` uses blocking `waitpid(pid,&st,0)` |
| 4 | CGI | **POST body ≥1024 B → 501** (so any real form post fails) | `feedInput()`: `if (dup2(fileFd,inputFds[1]) != -1) return false;` — inverted check **and** dups onto the pipe's *write* end. Bodies ≥1024 B take this temp-file path |
| 5 | CGI | **output >64 KB deadlocks the server** (permanent hang) | `ExecCgi()` does `waitpid()` *before* `feedOutput()` reads the pipe; child blocks writing a full pipe, parent blocks in waitpid |
| 6 | CGI | **child inherits the listening sockets** — after a hung CGI the port stays bound even once the server is killed (and CGI scripts can touch the server's sockets) | listen fds are not `FD_CLOEXEC` and aren't closed in the forked child before `execve` |

CGI bugs 3–6 are all in `features/cgi/CgiHandler.cpp` — the CGI subsystem can't
handle a >1 KB request body, a >64 KB response, or a slow script, and leaks the
listening sockets into every CGI process.

### WARN — spec/RFC deviations (defensible, be ready to explain)

| # | Behaviour | Note |
|---|-----------|------|
| 7 | Null-byte path `/hello.txt%00.jpg` → 200 | `decodeUrl` accepts `%00`; NUL truncates the C string at `realpath` |
| 8 | Body over `max_size` → **400**, not **413** | server rejects (good) but with the wrong status |
| 9 | `error_page` configured but never served | `HttpResponse::setError()`'s non-empty-page branch is empty |
| 10 | Boundary string inside file content truncates the upload | splitter matches bare `--boundary` instead of CRLF-anchored `\r\n--boundary`; harmless for conformant clients |

### Config-parser note

`autoindex off` is a **parse error** — only `autoindex on` is accepted; "off"
must be expressed by omitting the directive. nginx accepts `off`.
