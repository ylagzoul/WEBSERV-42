#!/usr/bin/env bash
# =============================================================================
#  Shared test infrastructure for webserv (sourced by run.sh and advanced.sh)
#  Provides: colours, counters, assertions, raw-HTTP wrappers, sandbox builder,
#            config generator, server launch/teardown, summary.
# =============================================================================
set -u

# ---- paths ------------------------------------------------------------------
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TDIR="$ROOT/tests"
SB="$TDIR/sandbox"
PY="$TDIR/http_raw.py"
BIN="$ROOT/webserv"
H="127.0.0.1"
P1=8080          # main.conf (also 8081)
P2=8082          # small.conf (max_size 100)
P3=8083          # adv.conf  (sacrificial instance for hang-prone CGI tests)
P4=8088          # vg.conf   (instance run under valgrind for the leak check)
MAIN="$SB/main.conf"; SMALL="$SB/small.conf"; ADV="$SB/adv.conf"; VG="$SB/vg.conf"

# ---- colours / counters -----------------------------------------------------
if [ -t 1 ]; then R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; N=$'\e[0m'
else R=; G=; Y=; B=; N=; fi
PASS=0; FAIL=0; WARN=0
declare -a FAILED=()
declare -a WARNED=()

sec(){ printf "\n${B}== %s ==${N}\n" "$1"; }
ok(){ PASS=$((PASS+1)); printf "  ${G}PASS${N} %s\n" "$1"; }
no(){ FAIL=$((FAIL+1)); FAILED+=("$1"); printf "  ${R}FAIL${N} %s\n" "$1"; }
wn(){ WARN=$((WARN+1)); WARNED+=("$1"); printf "  ${Y}WARN${N} %s\n" "$1"; }

eq(){ [ "${2:-}" = "${3:-}" ] && ok "$1 [=${3:-}]" || no "$1 [exp '${2:-}' got '${3:-}']"; }
inset(){ case " ${3:-} " in *" ${2:-} "*) ok "$1 [${2:-}]";; *) no "$1 [got '${2:-}', want: ${3:-}]";; esac; }
has(){ case "${3:-}" in *"${2:-}"*) ok "$1";; *) no "$1 [missing '${2:-}']";; esac; }
hasnt(){ case "${3:-}" in *"${2:-}"*) no "$1 [unexpected '${2:-}']";; *) ok "$1";; esac; }
inset_w(){ case " ${3:-} " in *" ${2:-} "*) ok "$1 [${2:-}]";; *) wn "$1 [got '${2:-}', want: ${3:-}]";; esac; }

# ---- raw HTTP wrappers (timeout-safe) --------------------------------------
st(){   local port=$1; shift; python3 "$PY" "$H" "$port" --timeout 6 --show status     "$@"; }
hd(){   local port=$1; shift; python3 "$PY" "$H" "$port" --timeout 6 --show headers    "$@"; }
bd(){   local port=$1; shift; python3 "$PY" "$H" "$port" --timeout 6 --show body       "$@"; }
sl(){   local port=$1; shift; python3 "$PY" "$H" "$port" --timeout 6 --show statusline "$@"; }
term(){ local port=$1; shift; python3 "$PY" "$H" "$port" --timeout 6 --show terminator "$@"; }
raw(){  local port=$1; shift; python3 "$PY" "$H" "$port" --timeout 6 --show raw        "$@"; }

# ---- build ------------------------------------------------------------------
build_server(){
  sec "BUILD"
  ( cd "$ROOT" && make -s ) && [ -x "$BIN" ] && ok "make -> binary exists" \
    || { no "build failed"; exit 1; }
}

# ---- sandbox ----------------------------------------------------------------
setup_sandbox(){
  sec "SANDBOX SETUP"
  rm -rf "$SB"; mkdir -p "$SB"/www/pub "$SB"/www/secret "$SB"/www/dir2 \
          "$SB"/www/errors "$SB"/www/cgi-bin "$SB"/uploads "$SB"/files "$SB"/nx
  rmdir "$SB"/nx     # a dir path that does NOT exist (for missing-dir tests)
  printf '<h1>INDEX OK</h1>'   > "$SB/www/index.html"
  printf 'HELLO_TXT_BODY_OK'   > "$SB/www/hello.txt"
  printf 'NOEXT_BODY_OK'       > "$SB/www/noext"
  printf 'PUB_FILE'            > "$SB/www/pub/a.txt"
  printf 'SECRET_FILE'         > "$SB/www/secret/s.txt"
  printf '<h1>CUSTOM 404</h1>' > "$SB/www/errors/404.html"
  printf '<h1>CUSTOM 500</h1>' > "$SB/www/errors/500.html"
  printf 'FILES_OK'            > "$SB/files/f.txt"
  cp "$ROOT/www/img.jpg" "$SB/www/img.jpg" 2>/dev/null || printf 'JPGDATA' > "$SB/www/img.jpg"
  cp "$ROOT"/www/cgi-bin/*.py "$SB/www/cgi-bin/" 2>/dev/null
  yes ABCDEFGHIJKLMNOPQRSTUVWXYZ12345678 | head -c 1048576 > "$SB/www/big.bin"
  yes ABCDEFGHIJKLMNOPQRSTUVWXYZ12345678 | head -c 5242880 > "$SB/www/huge.bin"
  ln -sf /etc "$SB/www/escape" 2>/dev/null

  # ---- advanced CGI fixtures ----
  printf '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("Content-Type: text/plain\\r\\n\\r\\n")\nsys.stdout.write("A"*200000)\n' > "$SB/www/cgi-bin/bigout.py"
  printf '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("Content-Type: text/plain\\r\\n\\r\\nhi")\nsys.exit(1)\n' > "$SB/www/cgi-bin/exitfail.py"
  printf '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("Content-Type: text/plain\\r\\n\\r\\n")\n' > "$SB/www/cgi-bin/nobody.py"
  printf '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("NO_HEADERS_JUST_BODY")\n' > "$SB/www/cgi-bin/nohdr.py"
  printf '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("Status: 302 Found\\r\\nLocation: /hello.txt\\r\\n\\r\\n")\n' > "$SB/www/cgi-bin/loc.py"
  printf '#!/usr/bin/env python3\nimport sys\nsys.stdout.write("Content-Type: text/plain\\r\\n\\r\\nIGNORED")\n' > "$SB/www/cgi-bin/noinput.py"
  chmod +x "$SB"/www/cgi-bin/*.py 2>/dev/null
  ok "sandbox built at $SB"

  write_configs
}

write_configs(){
  _common_locations(){ cat <<EOF
location /
    methods GET POST DELETE
    root $SB/www
    index index.html
    autoindex on

location /pub
    methods GET
    root $SB/www
    autoindex on

location /secret
    methods GET
    root $SB/www

location /files
    methods GET
    root $SB/files
    autoindex on

location /redirect
    methods GET
    return 301 http://localhost:8080/

location /upload
    methods POST
    upload on
    upload_dir $SB/uploads

location /badupload
    methods POST
    upload on
    upload_dir $SB/nx

location /cgi-bin
    methods GET POST
    root $SB/www
    extension .py /usr/bin/python3
EOF
  }
  { printf 'max_size 10485760\n\nerror_page 404 /errors/404.html\nerror_page 500 /errors/500.html\n\nlisten 127.0.0.1:8080\nlisten 0.0.0.0:8081\n\n'; _common_locations; } > "$MAIN"
  { printf 'max_size 10485760\n\nlisten 127.0.0.1:8083\n\n'; _common_locations; } > "$ADV"
  { printf 'max_size 10485760\n\nlisten 127.0.0.1:8088\n\n'; _common_locations; } > "$VG"
  cat > "$SMALL" <<EOF
max_size 100

listen 127.0.0.1:8082

location /
    methods GET POST DELETE
    root $SB/www
    index index.html
    autoindex on

location /upload
    methods POST
    upload on
    upload_dir $SB/uploads
EOF
  ok "configs written (main 10MB/8080+8081, small 100B/8082, adv 10MB/8083)"
}

# ---- server lifecycle -------------------------------------------------------
wait_port(){ for _ in $(seq 1 60); do
  python3 -c "import socket; socket.create_connection(('$H',$1),0.3)" 2>/dev/null && return 0
  sleep 0.1; done; return 1; }

port_free(){ ! python3 -c "import socket; socket.create_connection(('$H',$1),0.2)" 2>/dev/null; }

# SIGKILL any straggler server (SIGTERM is deferred while blocked in CGI waitpid)
# and any orphaned CGI children — they INHERIT the listening sockets (no
# FD_CLOEXEC) and keep the port bound after the server dies. Then wait until our
# ports are actually free before a fresh launch.
ensure_clean(){
  pkill -9 -x webserv 2>/dev/null
  pkill -9 -f "$SB/www/cgi-bin" 2>/dev/null
  for _ in $(seq 1 80); do
    port_free $P1 && port_free $P2 && port_free $P3 && port_free $P4 && return 0
    sleep 0.1
  done
  return 0
}

# ---- memory / fd leak check (valgrind) --------------------------------------
# Runs a fresh server under valgrind on its own port, exercises every handler
# path, then SIGINTs it (the server has no signal handler, so it terminates and
# valgrind writes its report). PASS iff definitely+indirectly lost == 0.
valgrind_leak_check(){
  sec "MEMORY / FD LEAK (valgrind)"
  if ! command -v valgrind >/dev/null 2>&1; then
    wn "valgrind not installed — memory check skipped"; return
  fi
  ensure_clean   # clear suite servers + any orphaned CGI children for a clean run
  local LOG="$SB/valgrind.log"
  # --child-silent-after-fork=yes: don't let valgrind wrap the CGI fork (it
  # otherwise interferes with clean shutdown of the parent under signal).
  valgrind --leak-check=full --show-leak-kinds=all --track-fds=yes \
           --trace-children=no --child-silent-after-fork=yes \
           --error-exitcode=0 --log-file="$LOG" "$BIN" "$VG" >/dev/null 2>&1 &
  local vp=$!
  local up=0
  for _ in $(seq 1 120); do port_free $P4 || { up=1; break; }; sleep 0.2; done
  if [ $up -ne 1 ]; then no "server failed to start under valgrind"; kill -9 $vp 2>/dev/null; return; fi
  ok "server started under valgrind ($P4)"
  # exercise every handler path so all allocation sites are hit
  st $P4 --path /hello.txt                                                          >/dev/null
  st $P4 --path /                                                                   >/dev/null
  st $P4 --path /pub/                                                               >/dev/null
  st $P4 --path /missing.xyz                                                        >/dev/null
  st $P4 --path /redirect                                                           >/dev/null
  st $P4 --path '/../../../../../../etc/passwd'                                     >/dev/null
  st $P4 --path "/$(printf 'a%.0s' $(seq 1 5000))"                                  >/dev/null
  bd $P4 --path /cgi-bin/hello.py                                                   >/dev/null
  st $P4 --method POST --path /cgi-bin/info.py --header 'Content-Type: text/plain' --body hello >/dev/null
  printf -- '--BB\r\nContent-Disposition: form-data; name="f"; filename="vg.txt"\r\n\r\nHI\r\n--BB--\r\n' > "$SB/vgu.bin"
  st $P4 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/vgu.bin" >/dev/null
  st $P4 --method DELETE --path /hello.txt                                          >/dev/null
  printf 'HELLO_TXT_BODY_OK' > "$SB/www/hello.txt"   # restore for later suites
  # Terminate so valgrind writes its report. The server blocks in poll(...,-1)
  # with no signal handler, so we must (a) keep the signal pending and (b) wake
  # poll() with a real request each iteration so valgrind can apply it.
  local gone=0
  for _ in $(seq 1 80); do
    kill -0 $vp 2>/dev/null || { gone=1; break; }
    kill -INT $vp 2>/dev/null
    curl -s --max-time 1 -o /dev/null "http://$H:$P4/hello.txt" 2>/dev/null
    sleep 0.15
  done
  if [ $gone -eq 0 ]; then
    kill -TERM $vp 2>/dev/null
    curl -s --max-time 1 -o /dev/null "http://$H:$P4/hello.txt" 2>/dev/null
    sleep 1
  fi
  kill -9 $vp 2>/dev/null
  # parse the report
  if ! grep -q "LEAK SUMMARY" "$LOG" 2>/dev/null; then
    wn "valgrind wrote no leak summary (no clean exit) — inspect $LOG"; return
  fi
  # Primary verdict: real leaks are "definitely lost" + "indirectly lost".
  # (still-reachable = globals/Config, fine for 42. The ERROR/fd counts are
  #  inflated by the wake-up pokes used to terminate the server, so we flag
  #  their presence but don't print the misleading totals — see $LOG for detail.)
  local def ind reach
  def=$(grep "definitely lost:" "$LOG"  | grep -oE "[0-9,]+ bytes" | head -1)
  ind=$(grep "indirectly lost:" "$LOG"  | grep -oE "[0-9,]+ bytes" | head -1)
  reach=$(grep "still reachable:" "$LOG"| grep -oE "[0-9,]+ bytes" | head -1)
  if grep -q "definitely lost: 0 bytes" "$LOG" && grep -q "indirectly lost: 0 bytes" "$LOG"; then
    ok "no memory leak (definitely lost: 0, indirectly lost: 0)"
  else
    no "memory leak (definitely lost: ${def:-?}, indirectly lost: ${ind:-?}) — see $LOG"
  fi
  printf "       still reachable: %s (globals/Config — acceptable for 42)\n" "${reach:-?}"
  # ERROR SUMMARY is inflated by --track-fds "Open ... socket ... at exit"
  # reports (fds still open when we SIGTERM the poll()-blocked server — not a
  # bug). Count only genuine memory-safety errors instead.
  local memerr
  memerr=$(grep -cE "Invalid (read|write|free)|uninitialised|Mismatched free|Source and destination overlap" "$LOG")
  if [ "${memerr:-0}" -eq 0 ]; then
    ok "valgrind: no invalid-access / uninitialised-value errors"
  else
    wn "valgrind reports $memerr invalid-access/uninitialised error(s) — see $LOG"
  fi
}

summary(){
  sec "SUMMARY"
  printf "  ${G}PASS %d${N}   ${R}FAIL %d${N}   ${Y}WARN %d${N}\n" "$PASS" "$FAIL" "$WARN"
  if [ "${#FAILED[@]}" -gt 0 ]; then
    printf "\n${R}Failures (defects to fix):${N}\n"
    for f in "${FAILED[@]}"; do printf "  - %s\n" "$f"; done
  fi
  if [ "${#WARNED[@]}" -gt 0 ]; then
    printf "\n${Y}Warnings (spec/RFC deviations — discuss at defense):${N}\n"
    for w in "${WARNED[@]}"; do printf "  - %s\n" "$w"; done
  fi
  echo
  [ "$FAIL" -eq 0 ]
}
