#!/usr/bin/env python3
import os, sys

body = sys.stdin.read()
print("Content-Type: text/plain\r")
print("\r")
print("METHOD:   " + os.environ.get("REQUEST_METHOD",""))
print("QUERY:    " + os.environ.get("QUERY_STRING",""))
print("CT:       " + os.environ.get("CONTENT_TYPE",""))
print("CLEN:     " + os.environ.get("CONTENT_LENGTH",""))
print("SCRIPT:   " + os.environ.get("SCRIPT_NAME",""))
print("BODY_LEN: " + str(len(body)))
print("BODY:     " + body)
