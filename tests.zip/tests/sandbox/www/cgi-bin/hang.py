import time
time.sleep(30)
print("Content-Type: text/plain\r\n\r\nshould never get here")
