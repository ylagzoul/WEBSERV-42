#!/usr/bin/env python3
import sys, os
body = sys.stdin.read()
print("Content-Type: text/plain\r")
print("\r")
print("Hello from CGI")
print("METHOD:", os.environ.get("REQUEST_METHOD", ""))
print("QUERY:", os.environ.get("QUERY_STRING", ""))
print("BODY:", body)
