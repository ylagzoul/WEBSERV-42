#!/usr/bin/env python3

import sys
import os

body = sys.stdin.read()

print("Content-Type: text/plain")
print()

print("===== CGI REQUEST =====")
print()

print("BODY:")
print(body)
print()

print("ENV VARIABLES:")
for key, value in os.environ.items():
    print(f"{key}={value}")