#!/usr/bin/env python3
import sys
sys.stdout.write("Status: 302 Found\r\nLocation: /hello.txt\r\n\r\n")
