#!/usr/bin/env python3

import sys
import time

# CGI headers
sys.stdout.write("Status: 200 OK\r\n")
sys.stdout.write("Content-Type: text/plain\r\n")
sys.stdout.write("Transfer-Encoding: chunked\r\n")
sys.stdout.write("\r\n")
sys.stdout.flush()


def chunk(data):
    sys.stdout.write(f"{len(data):X}\r\n")
    sys.stdout.write(data)
    sys.stdout.write("\r\n")
    sys.stdout.flush()


chunk("Hello ")
time.sleep(1)

chunk("from ")
time.sleep(1)

chunk("CGI!\n")
time.sleep(1)

# Final chunk
sys.stdout.write("0\r\n\r\n")
sys.stdout.flush()