#!/usr/bin/env python3
import sys
sys.stdout.write("NO_HEADERS_JUST_BODY")
