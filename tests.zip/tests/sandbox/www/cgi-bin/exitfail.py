#!/usr/bin/env python3
import sys
sys.stdout.write("Content-Type: text/plain\r\n\r\nhi")
sys.exit(1)
