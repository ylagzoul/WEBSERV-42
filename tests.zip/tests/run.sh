#!/usr/bin/env bash
# =============================================================================
#  webserv — full project test suite (baseline functional + robustness)
#  Covers: HTTP compliance, static files, path safety, redirects, upload,
#          DELETE, CGI, error pages, config/locations, stress/robustness.
#  For deeper/adversarial edge cases see: tests/advanced.sh
#
#  Usage:   bash tests/run.sh
#  Outcomes: PASS (correct) · FAIL (defect to fix) · WARN (debatable/spec gap)
# =============================================================================
source "$(dirname "$0")/lib.sh"

build_server
setup_sandbox
valgrind_leak_check   # run first, in a fresh environment (most reliable for valgrind)
ensure_clean

sec "LAUNCH SERVERS"
"$BIN" "$MAIN"  > "$SB/srvA.log" 2>&1 & SRVA=$!
"$BIN" "$SMALL" > "$SB/srvB.log" 2>&1 & SRVB=$!
cleanup(){ kill -9 $SRVA $SRVB 2>/dev/null; pkill -9 -x webserv 2>/dev/null; wait 2>/dev/null; }
trap cleanup EXIT
wait_port $P1 && ok "server A up on $P1/8081" || { no "server A failed"; cat "$SB/srvA.log"; exit 1; }
wait_port $P2 && ok "server B up on $P2"      || { no "server B failed"; cat "$SB/srvB.log"; }

# =============================================================================
sec "1. HTTP COMPLIANCE"
eq   "GET / status line is 200"             200 "$(st $P1 --path /)"
has  "status line text 'HTTP/1.1 200 OK'"   "HTTP/1.1 200 OK" "$(python3 "$PY" $H $P1 --show statusline --path /)"
eq   "missing Host on HTTP/1.1 -> 400"      400 "$(st $P1 --no-host --path /)"
eq   "HTTP/1.0 without Host allowed -> 200" 200 "$(st $P1 --http 1.0 --no-host --path /)"
inset_w "unknown method PUT -> 400/405/501" "$(st $P1 --method PUT --path /)" "400 405 501"
inset_w "bad version HTTP/2.0 -> 400/505"   "$(st $P1 --http 2.0 --path /)"   "400 505"
# keep-alive: two SEQUENTIAL requests on ONE socket (send, read full resp, reuse)
KA=$(python3 - "$H" "$P1" <<'PYKA'
import socket, sys
host, port = sys.argv[1], int(sys.argv[2])
def read_full(s):
    buf=b""
    s.settimeout(4)
    try:
        while b"\r\n\r\n" not in buf:
            d=s.recv(4096);
            if not d: return buf
            buf+=d
        head,_,rest=buf.partition(b"\r\n\r\n")
        cl=0
        for ln in head.split(b"\r\n"):
            if ln.lower().startswith(b"content-length:"):
                cl=int(ln.split(b":",1)[1].strip())
        while len(rest)<cl:
            d=s.recv(4096)
            if not d: break
            rest+=d
    except socket.timeout:
        pass
    return head+b"\r\n\r\n"+rest
try:
    s=socket.create_connection((host,port),4)
    s.sendall(b"GET /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: keep-alive\r\n\r\n")
    r1=read_full(s)
    s.sendall(b"GET /hello.txt HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n")
    r2=read_full(s)
    s.close()
    n=r1.count(b"HTTP/1.")+r2.count(b"HTTP/1.")
    ok1=b"HELLO_TXT_BODY_OK" in r1
    ok2=b"HELLO_TXT_BODY_OK" in r2
    print(n if (ok1 and ok2) else 1)
except Exception:
    print("ERR")
PYKA
)
eq   "keep-alive: 2 sequential reqs on 1 conn" 2 "$KA"
# Content-Length accuracy on static file
CL=$(hd $P1 --path /hello.txt | tr -d '\r' | awk -F': ' 'tolower($1)=="content-length"{print $2}')
eq   "Content-Length matches body (17)"     17 "$CL"
# Content-Type mapping
has  "Content-Type img.jpg = image/jpeg"    "image/jpeg" "$(hd $P1 --path /img.jpg)"
has  "Content-Type hello.txt = text/plain"  "text/plain" "$(hd $P1 --path /hello.txt)"
has  "Content-Type index = text/html"       "text/html"  "$(hd $P1 --path /)"
has  "Content-Type noext = octet-stream"    "application/octet-stream" "$(hd $P1 --path /noext)"
# URL-encoded path decoded ( /hello.txt )
eq   "URL-encoded path decoded -> 200"      200 "$(st $P1 --path '/%68%65%6c%6c%6f.txt')"
has  "URL-encoded path serves right file"   "HELLO_TXT_BODY_OK" "$(bd $P1 --path '/%68%65%6c%6c%6f.txt')"

# =============================================================================
sec "2. STATIC FILES"
eq   "GET /hello.txt -> 200"                200 "$(st $P1 --path /hello.txt)"
has  "  body correct"                       "HELLO_TXT_BODY_OK" "$(bd $P1 --path /hello.txt)"
eq   "GET /missing -> 404"                  404 "$(st $P1 --path /missing.xyz)"
has  "index.html served for /"             "INDEX OK"  "$(bd $P1 --path /)"
eq   "dir /pub  (no slash) -> 200"          200 "$(st $P1 --path /pub)"
eq   "dir /pub/ (slash)    -> 200"          200 "$(st $P1 --path /pub/)"
has  "autoindex lists entry a.txt"          "a.txt" "$(bd $P1 --path /pub/)"
eq   "autoindex OFF /secret/ -> 403"        403 "$(st $P1 --path /secret/)"
# large file streamed fully
BIGN=$(bd $P1 --path /big.bin --timeout 15 | wc -c)
eq   "1MB file served fully (byte count)"   1048576 "$BIGN"

# =============================================================================
sec "3. PATH SAFETY / TRAVERSAL"
TRAV='/../../../../../../../../etc/passwd'
inset "deep traversal blocked (403/404)"    "$(st $P1 --path "$TRAV")" "403 404"
hasnt "  traversal body has no 'root:'"     "root:" "$(bd $P1 --path "$TRAV")"
ENC='/%2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd'
inset "encoded traversal blocked (403/404)" "$(st $P1 --path "$ENC")" "403 404"
LONG="/$(printf 'a%.0s' $(seq 1 5000))"
eq   "URI > 4096 bytes -> 414"              414 "$(st $P1 --path "$LONG")"
inset "symlink escape /escape/passwd blocked" "$(st $P1 --path /escape/passwd)" "403 404"
hasnt "  symlink body has no 'root:'"       "root:" "$(bd $P1 --path /escape/passwd)"
# null byte in path
NB=$(st $P1 --path '/hello.txt%00.jpg')
inset_w "null-byte path not 200 (ideal)"    "$NB" "400 403 404"

# =============================================================================
sec "4. REDIRECTS"
eq   "GET /redirect -> 301"                 301 "$(st $P1 --path /redirect)"
has  "  Location header set"                "Location: http://localhost:8080/" "$(hd $P1 --path /redirect)"
T=$(term $P1 --path /redirect)
if [ "$T" = "YES" ]; then ok "redirect response has header terminator (\\r\\n\\r\\n)"
else no "redirect response MISSING header terminator -> clients HANG (empty-body bug)"; fi

# =============================================================================
sec "5. POST / MULTIPART UPLOAD"
BD="--BB
Content-Disposition: form-data; name=\"file\"; filename=\"up1.txt\"
Content-Type: text/plain

UPLOAD_CONTENT_OK
--BB--
"
# convert LF to CRLF for a valid multipart body
printf '%s' "$BD" | sed 's/$/\r/' > "$SB/mp1.bin"
eq   "valid upload -> 200" 200 "$(st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mp1.bin")"
sleep 0.2
[ -f "$SB/uploads/up1.txt" ] && ok "uploaded file exists on disk" || no "uploaded file NOT written"
[ -f "$SB/uploads/up1.txt" ] && has "  content correct" "UPLOAD_CONTENT_OK" "$(cat "$SB/uploads/up1.txt" 2>/dev/null)"
# missing boundary
eq   "multipart w/o boundary -> 400" 400 "$(st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data' --body 'x')"
# wrong content-type
eq   "non-multipart content-type -> 400" 400 "$(st $P1 --method POST --path /upload --header 'Content-Type: text/plain' --body 'x')"
# malicious filename (traversal) -> sanitized into uploads/
MAL="--BB
Content-Disposition: form-data; name=\"file\"; filename=\"../../evil.txt\"
Content-Type: text/plain

EVIL
--BB--
"
printf '%s' "$MAL" | sed 's/$/\r/' > "$SB/mp2.bin"
st $P1 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mp2.bin" >/dev/null
sleep 0.2
[ -f "$SB/evil.txt" ] && no "traversal filename escaped uploads dir!" || ok "traversal filename did NOT escape"
[ -f "$SB/uploads/evil.txt" ] && ok "  sanitized to uploads/evil.txt" || wn "  sanitized name not found (check sanitizer)"
# upload dir missing -> 500
eq   "upload to missing dir -> 500" 500 "$(st $P1 --method POST --path /badupload --header 'Content-Type: multipart/form-data; boundary=BB' --body-file "$SB/mp1.bin")"
# oversize body on small.conf (max 100) -> spec says 413
BIG200=$(printf 'x%.0s' $(seq 1 200))
inset_w "body > max_size -> 413 (got)" "$(st $P2 --method POST --path /upload --header 'Content-Type: multipart/form-data; boundary=BB' --body "$BIG200")" "413"

# =============================================================================
sec "6. DELETE"
printf 'TODELETE' > "$SB/www/del.txt"
eq   "DELETE existing file -> 200" 200 "$(st $P1 --method DELETE --path /del.txt)"
[ -f "$SB/www/del.txt" ] && no "  file still on disk after DELETE" || ok "  file removed from disk"
eq   "DELETE again (missing) -> 404" 404 "$(st $P1 --method DELETE --path /del.txt)"
eq   "DELETE a directory -> 405" 405 "$(st $P1 --method DELETE --path /dir2)"
inset "DELETE traversal blocked" "$(st $P1 --method DELETE --path "$TRAV")" "403 404"

# =============================================================================
sec "7. CGI"
has  "GET hello.py body"        "Hello from CGI" "$(bd $P1 --path /cgi-bin/hello.py)"
has  "QUERY_STRING preserved"   "a=1&b=2"        "$(bd $P1 --path '/cgi-bin/info.py?a=1&b=2')"
POUT="$(bd $P1 --method POST --path /cgi-bin/info.py --header 'Content-Type: text/plain' --body 'hello')"
has  "POST CONTENT_LENGTH=5"    "CLEN:     5"    "$POUT"
has  "POST body read from stdin" "BODY_LEN: 5"   "$POUT"
eq   "CGI custom Status: -> 200" 200 "$(st $P1 --path /cgi-bin/chunk.py)"
has  "CGI chunk.py body"        "Hello"          "$(bd $P1 --path /cgi-bin/chunk.py)"
has  "REDIRECT_STATUS=200 in env" "REDIRECT_STATUS=200" "$(bd $P1 --path /cgi-bin/test.py)"

# =============================================================================
sec "8. ERROR PAGES"
eq   "404 returns 404"          404 "$(st $P1 --path /missing.xyz)"
B404="$(bd $P1 --path /missing.xyz)"
if printf '%s' "$B404" | grep -q "CUSTOM 404"; then ok "custom error_page served"
else wn "custom error_page configured but NOT served (got default body)"; fi

# =============================================================================
sec "9. CONFIG / LOCATIONS"
eq   "port 8080 serves"         200 "$(st $P1 --path /)"
eq   "port 8081 serves"         200 "$(st 8081 --path /)"
has  "/cgi-bin overrides / (specificity)" "Hello from CGI" "$(bd $P1 --path /cgi-bin/hello.py)"
eq   "method not allowed POST /pub -> 405" 405 "$(st $P1 --method POST --path /pub/)"
eq   "method not allowed DELETE /files -> 405" 405 "$(st $P1 --method DELETE --path /files/f.txt)"

# =============================================================================
sec "10. STRESS / ROBUSTNESS"
# malformed request, server must survive
printf 'GARBAGE !!! not http\r\n\r\n' | python3 "$PY" $H $P1 --raw --show status >/dev/null 2>&1
eq   "alive after malformed request" 200 "$(st $P1 --path /)"
# disconnect mid-transfer
python3 -c "import socket;s=socket.create_connection(('$H',$P1),3);s.sendall(b'GET / HTTP/1.1\r\nHost: x\r\nContent-Length: 999\r\n\r\npartial');s.close()" 2>/dev/null
eq   "alive after mid-transfer disconnect" 200 "$(st $P1 --path /)"
# 100 concurrent requests (small file)
CC=$(seq 1 100 | xargs -P20 -I{} curl -s --max-time 8 -o /dev/null -w "%{http_code}\n" "http://$H:$P1/hello.txt" | grep -c "^200")
eq   "100 concurrent GET all 200" 100 "$CC"
# many clients each pulling a BIG (5MB) file at once -> all must arrive intact
rm -f "$SB"/dl_*.tmp; bpids=()
for i in $(seq 1 8); do curl -s --max-time 30 -o "$SB/dl_$i.tmp" "http://$H:$P1/huge.bin" & bpids+=($!); done
wait "${bpids[@]}" 2>/dev/null
bigok=0; for i in $(seq 1 8); do [ "$(wc -c < "$SB/dl_$i.tmp" 2>/dev/null)" = "5242880" ] && bigok=$((bigok+1)); done
rm -f "$SB"/dl_*.tmp
eq   "8 concurrent 5MB downloads all intact" 8 "$bigok"
# a slow (throttled) big download must NOT block a fast small request (true interleave)
curl -s --max-time 40 --limit-rate 50k -o /dev/null "http://$H:$P1/huge.bin" & slow=$!
sleep 1
s0=$(date +%s.%N); sc=$(curl -s --max-time 10 -o /dev/null -w "%{http_code}" "http://$H:$P1/hello.txt"); s1=$(date +%s.%N)
kill $slow 2>/dev/null; wait $slow 2>/dev/null
slat=$(awk "BEGIN{printf \"%.2f\", $s1-$s0}")
if [ "$sc" = "200" ] && awk "BEGIN{exit !($slat<3)}"; then ok "slow client does NOT block others (small req ${slat}s)"
else no "slow client BLOCKS server (small req status=$sc, ${slat}s)"; fi
# fd leak over 60 requests (each curl opens then closes a keep-alive connection)
fdc(){ ls /proc/$1/fd 2>/dev/null | wc -l; }
F0=$(fdc $SRVA)
for _ in $(seq 1 60); do curl -s --max-time 5 -o /dev/null "http://$H:$P1/img.jpg"; done
F1=$(fdc $SRVA)
DELTA=$((F1-F0))
CW=$(ss -tan 2>/dev/null | grep -c "CLOSE-WAIT.*:$P1 ")
if [ "$DELTA" -le 3 ]; then ok "no connection-fd leak (delta=$DELTA over 60 reqs)"
else no "connection-fd leak: delta=$DELTA over 60 reqs${CW:+, $CW sockets in CLOSE_WAIT} (server never close()s disconnected clients)"; fi

# =============================================================================
sec "11. CGI TIMEOUT (run last — blocks single-thread server ~30s if no timeout)"
T0=$(date +%s)
HS=$(st $P1 --path /cgi-bin/hang.py --timeout 8)
T1=$(date +%s)
if [ $((T1-T0)) -lt 8 ] && [ "$HS" != "ERR" ] && [ "$HS" != "EMPTY" ]; then
  ok "hanging CGI returned in time (status $HS) — has a timeout"
else
  no "hanging CGI did NOT return within 8s — no CGI timeout, server blocks (DoS)"
fi

# =============================================================================
summary && exit 0 || exit 1
