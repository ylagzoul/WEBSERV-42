#!/usr/bin/env python3
# Raw HTTP/1.1 client for webserv test suite.
# Gives full control over the request bytes and never normalizes the path,
# so it can test missing Host, bad versions, traversal, pipelining, chunked,
# and malformed responses (e.g. a redirect with no header terminator) without
# hanging the test runner.
import socket
import sys
import time
import argparse


def build_request(a):
    lines = ["%s %s HTTP/%s" % (a.method, a.path, a.http)]
    has_host = False
    has_clen = False
    has_conn = False
    for h in a.header:
        lines.append(h)
        low = h.lower()
        if low.startswith("host:"):
            has_host = True
        if low.startswith("content-length:"):
            has_clen = True
        if low.startswith("connection:"):
            has_conn = True
    if not has_host and not a.no_host:
        lines.append("Host: %s" % a.host)
    if a.body_file is not None:
        with open(a.body_file, "rb") as f:
            body = f.read()
    else:
        body = a.body.encode() if a.body is not None else b""
    if body and not has_clen and not a.no_clen:
        lines.append("Content-Length: %d" % len(body))
    if not has_conn:
        lines.append("Connection: close")  # so server closes -> we read EOF, no hang
    head = ("\r\n".join(lines) + "\r\n\r\n").encode()
    return head + body


def main():
    p = argparse.ArgumentParser()
    p.add_argument("host")
    p.add_argument("port", type=int)
    p.add_argument("--timeout", type=float, default=5.0)
    p.add_argument("--method", default="GET")
    p.add_argument("--path", default="/")
    p.add_argument("--http", default="1.1")
    p.add_argument("--header", action="append", default=[])
    p.add_argument("--body", default=None)
    p.add_argument("--body-file", dest="body_file", default=None)
    p.add_argument("--no-host", action="store_true")
    p.add_argument("--no-clen", action="store_true")
    p.add_argument("--raw", action="store_true",
                   help="read literal request bytes from stdin")
    p.add_argument("--show", default="status",
                   choices=["status", "headers", "body", "raw",
                            "terminator", "bytes", "statusline"])
    a = p.parse_args()

    data = sys.stdin.buffer.read() if a.raw else build_request(a)

    try:
        # small retry: absorb transient localhost pressure (TIME_WAIT/backlog),
        # not a genuinely-down server (which fails all attempts).
        s = None
        for attempt in range(4):
            try:
                s = socket.create_connection((a.host, a.port), timeout=a.timeout)
                break
            except OSError:
                if attempt == 3:
                    raise
                time.sleep(0.2)
        s.settimeout(a.timeout)
        s.sendall(data)
        chunks = []
        try:
            while True:
                b = s.recv(65536)
                if not b:
                    break
                chunks.append(b)
        except socket.timeout:
            pass
        s.close()
        resp = b"".join(chunks)
    except Exception:
        print("ERR")
        return 0

    if not resp:
        print("EMPTY")
        return 0

    sep = resp.find(b"\r\n\r\n")

    if a.show == "terminator":
        print("YES" if sep != -1 else "NO")
    elif a.show == "status":
        parts = resp.split(b"\r\n", 1)[0].split()
        print(parts[1].decode() if len(parts) >= 2 else "NOSTATUS")
    elif a.show == "statusline":
        sys.stdout.write(resp.split(b"\r\n", 1)[0].decode(errors="replace"))
    elif a.show == "headers":
        sys.stdout.write((resp[:sep] if sep != -1 else resp).decode(errors="replace"))
    elif a.show == "body":
        sys.stdout.buffer.write(resp[sep + 4:] if sep != -1 else b"")
    elif a.show == "bytes":
        print(len(resp))
    else:  # raw
        sys.stdout.buffer.write(resp)
    return 0


if __name__ == "__main__":
    sys.exit(main())
